library(testthat)
library(trajConserve)

test_check("trajConserve")