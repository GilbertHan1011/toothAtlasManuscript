## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  library(trajConserve)
#  library(Seurat)
#  
#  # Create a 3D trajectory array from a Seurat object
#  trajectory_data <- seurat_to_trajectory_array(
#    seurat_obj = your_seurat_object,
#    pseudo_col = "your_pseudotime_column",
#    project_col = "your_batch_column"
#  )

## ----eval=FALSE---------------------------------------------------------------
#  # Run model for a single gene
#  gene_idx <- 10  # Example gene index
#  model <- run_trajectory_model(trajectory_data$reshaped_data, gene_idx)
#  
#  # Visualize results
#  plot_results_brms(model)

## ----eval=FALSE---------------------------------------------------------------
#  # Run models for multiple genes in parallel
#  models <- run_multiple_models(
#    trajectory_data$reshaped_data,
#    gene_indices = 1:20,  # First 20 genes
#    parallel = TRUE,
#    n_cores = 4
#  )

